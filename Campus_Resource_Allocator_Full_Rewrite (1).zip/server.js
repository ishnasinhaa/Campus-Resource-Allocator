require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");
const app = express();
const PORT = Number(process.env.PORT || 3000);
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "resource",
  waitForConnections: true, connectionLimit: 10, queueLimit: 0
});

async function initDb() {
  await pool.query(`CREATE TABLE IF NOT EXISTS cra_resources (
    id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL UNIQUE,
    category VARCHAR(80) NOT NULL, location VARCHAR(120) DEFAULT '',
    capacity INT NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  ) ENGINE=InnoDB`);
  await pool.query(`CREATE TABLE IF NOT EXISTS cra_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY, requester_name VARCHAR(120) NOT NULL,
    requester_role ENUM('Student','Faculty','DSW','Admin') NOT NULL DEFAULT 'Student',
    requester_email VARCHAR(180) DEFAULT '', resource_id INT NOT NULL,
    purpose VARCHAR(255) NOT NULL, booking_date DATE NOT NULL,
    start_time TIME NOT NULL, end_time TIME NOT NULL, attendees INT NOT NULL DEFAULT 1,
    overnight TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('Pending','Approved','Rejected','Cancelled') NOT NULL DEFAULT 'Pending',
    edit_status ENUM('None','Pending','Approved','Rejected') NOT NULL DEFAULT 'None',
    proposed_date DATE DEFAULT NULL, proposed_start TIME DEFAULT NULL, proposed_end TIME DEFAULT NULL,
    faculty_note VARCHAR(500) DEFAULT NULL, reviewed_by VARCHAR(120) DEFAULT NULL,
    reviewed_at TIMESTAMP NULL DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_cra_resource FOREIGN KEY (resource_id) REFERENCES cra_resources(id)
  ) ENGINE=InnoDB`);
  await pool.query(`CREATE TABLE IF NOT EXISTS cra_approvals (
    id INT AUTO_INCREMENT PRIMARY KEY, booking_id INT NOT NULL,
    approver_role ENUM('Faculty','DSW','Admin') NOT NULL,
    approver_name VARCHAR(120) NOT NULL,
    decision ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    note VARCHAR(500) DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reviewed_at TIMESTAMP NULL DEFAULT NULL,
    CONSTRAINT fk_cra_approval_booking FOREIGN KEY (booking_id) REFERENCES cra_bookings(id) ON DELETE CASCADE
  ) ENGINE=InnoDB`);
  const [count] = await pool.query("SELECT COUNT(*) n FROM cra_resources");
  if (!count[0].n) {
    await pool.query(`INSERT INTO cra_resources(name,category,location,capacity) VALUES
    ('Computer Lab 204','Laboratory','Block B',40),('Seminar Hall','Hall','Academic Block',120),
    ('Amphitheatre','Outdoor Venue','Central Campus',200),('Classroom 301','Classroom','Block C',60),
    ('Projector Kit','Equipment','IT Store',1),('Sports Court','Sports Facility','Sports Complex',30),
    ('Meeting Room 2','Meeting Room','Admin Block',12),('Microphone and Speaker Set','Equipment','IT Store',1)`);
  }
}
const asyncRoute = fn => (req,res,next)=>Promise.resolve(fn(req,res,next)).catch(next);

app.get('/api/health', asyncRoute(async (_req,res)=>{await pool.query('SELECT 1');res.json({ok:true,message:'MySQL connected'});}));
app.get('/api/resources', asyncRoute(async (_req,res)=>{
  const [rows]=await pool.query('SELECT id,name,category,location,capacity,active FROM cra_resources ORDER BY active DESC,category,name');
  res.json(rows);
}));
app.post('/api/resources', asyncRoute(async (req,res)=>{
  const {name,category,location='',capacity=0}=req.body;
  if(!name||!category) return res.status(400).json({error:'Resource name and category are required.'});
  const [r]=await pool.query('INSERT INTO cra_resources(name,category,location,capacity) VALUES(?,?,?,?)',[name.trim(),category.trim(),location.trim(),Math.max(0,Number(capacity)||0)]);
  res.status(201).json({id:r.insertId,message:'Resource added.'});
}));
app.patch('/api/resources/:id', asyncRoute(async (req,res)=>{
  const {active}=req.body;
  await pool.query('UPDATE cra_resources SET active=? WHERE id=?',[active?1:0,req.params.id]);
  res.json({message:'Resource updated.'});
}));
app.get('/api/summary', asyncRoute(async (_req,res)=>{
  const [[a]]=await pool.query('SELECT COUNT(*) total FROM cra_bookings');
  const [[b]]=await pool.query("SELECT COUNT(*) total FROM cra_bookings WHERE status='Pending'");
  const [[c]]=await pool.query("SELECT COUNT(*) total FROM cra_bookings WHERE status='Approved'");
  const [[d]]=await pool.query('SELECT COUNT(*) total FROM cra_resources WHERE active=1');
  const [[e]]=await pool.query("SELECT COUNT(*) total FROM cra_bookings WHERE status='Rejected'");
  res.json({total:a.total,pending:b.total,approved:c.total,resources:d.total,rejected:e.total});
}));
app.get('/api/bookings', asyncRoute(async (req,res)=>{
  const {name='',role='',status=''}=req.query;
  let sql=`SELECT b.*, DATE_FORMAT(b.booking_date,'%Y-%m-%d') booking_date,
    TIME_FORMAT(b.start_time,'%H:%i') start_time,TIME_FORMAT(b.end_time,'%H:%i') end_time,
    DATE_FORMAT(b.proposed_date,'%Y-%m-%d') proposed_date,
    TIME_FORMAT(b.proposed_start,'%H:%i') proposed_start,TIME_FORMAT(b.proposed_end,'%H:%i') proposed_end,
    r.name resource_name,r.category,r.location,r.capacity
    FROM cra_bookings b JOIN cra_resources r ON r.id=b.resource_id WHERE 1=1`;
  const p=[];
  if(name.trim()){sql+=' AND LOWER(b.requester_name)=LOWER(?)';p.push(name.trim());}
  if(status){sql+=' AND b.status=?';p.push(status);}
  sql+=' ORDER BY b.created_at DESC';
  const [rows]=await pool.query(sql,p);
  res.json(rows);
}));
app.get('/api/approvals', asyncRoute(async (_req,res)=>{
  const [rows]=await pool.query(`SELECT a.*,b.requester_name,b.purpose,b.booking_date,r.name resource_name
    FROM cra_approvals a JOIN cra_bookings b ON b.id=a.booking_id JOIN cra_resources r ON r.id=b.resource_id
    ORDER BY a.created_at DESC`);
  res.json(rows);
}));
app.post('/api/bookings', asyncRoute(async (req,res)=>{
  const {requester_name,requester_email='',resource_id,purpose,booking_date,start_time,end_time,attendees=1,overnight=false}=req.body;
  if(!requester_name||!resource_id||!purpose||!booking_date||!start_time||!end_time) return res.status(400).json({error:'Fill in your name, resource, purpose, date and times.'});
  if(start_time>=end_time) return res.status(400).json({error:'End time must be later than start time.'});
  const n=Number(attendees);
  if(!Number.isInteger(n)||n<1) return res.status(400).json({error:'Attendees must be at least 1.'});
  const [rs]=await pool.query('SELECT id,capacity FROM cra_resources WHERE id=? AND active=1',[Number(resource_id)]);
  if(!rs.length) return res.status(400).json({error:'Choose an active resource.'});
  if(rs[0].capacity>0&&n>rs[0].capacity) return res.status(400).json({error:`Capacity limit is ${rs[0].capacity}.`});
  const [conflicts]=await pool.query(`SELECT id FROM cra_bookings WHERE resource_id=? AND booking_date=?
    AND status IN ('Pending','Approved') AND start_time<? AND end_time>? LIMIT 1`,
    [Number(resource_id),booking_date,end_time,start_time]);
  if(conflicts.length) return res.status(409).json({error:'This resource already has a pending or approved booking at that time.'});
  const isOvernight=overnight?1:0;
  const [result]=await pool.query(`INSERT INTO cra_bookings
    (requester_name,requester_role,requester_email,resource_id,purpose,booking_date,start_time,end_time,attendees,overnight,status)
    VALUES(?, 'Student', ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')`,
    [requester_name.trim(),requester_email,Number(resource_id),purpose.trim(),booking_date,start_time,end_time,n,isOvernight]);
  await pool.query("INSERT INTO cra_approvals(booking_id,approver_role,approver_name,decision) VALUES(?, 'Faculty', '', 'Pending')",[result.insertId]);
  if(isOvernight) await pool.query("INSERT INTO cra_approvals(booking_id,approver_role,approver_name,decision) VALUES(?, 'DSW', '', 'Pending')",[result.insertId]);
  res.status(201).json({id:result.insertId,message:isOvernight?'Overnight request saved; Faculty and DSW approval required.':'Booking request saved; awaiting faculty approval.'});
}));
app.patch('/api/bookings/:id/review', asyncRoute(async (req,res)=>{
  const {decision,approver_role='Faculty',approver_name,note=''}=req.body;
  if(!['Approved','Rejected'].includes(decision)) return res.status(400).json({error:'Decision must be Approved or Rejected.'});
  if(!['Faculty','DSW','Admin'].includes(approver_role)) return res.status(400).json({error:'Invalid approver role.'});
  if(!approver_name||!approver_name.trim()) return res.status(400).json({error:'Enter the reviewer name.'});
  const [rows]=await pool.query('SELECT * FROM cra_bookings WHERE id=?',[req.params.id]);
  if(!rows.length) return res.status(404).json({error:'Booking not found.'});
  const b=rows[0];
  if(b.status!=='Pending') return res.status(409).json({error:'Only pending bookings can be reviewed.'});
  if(approver_role==='DSW'&&!b.overnight) return res.status(400).json({error:'DSW review is only required for overnight bookings.'});
  if(decision==='Approved'&&approver_role==='Faculty'){
    const [conf]=await pool.query(`SELECT id FROM cra_bookings WHERE id<>? AND resource_id=? AND booking_date=?
      AND status='Approved' AND start_time<? AND end_time>? LIMIT 1`,
      [b.id,b.resource_id,b.booking_date,b.end_time,b.start_time]);
    if(conf.length) return res.status(409).json({error:'Cannot approve: an approved booking overlaps this time.'});
  }
  await pool.query(`UPDATE cra_approvals SET approver_name=?,decision=?,note=?,reviewed_at=CURRENT_TIMESTAMP
    WHERE booking_id=? AND approver_role=?`,[approver_name.trim(),decision,note||null,b.id,approver_role]);
  const [ap]=await pool.query('SELECT approver_role,decision FROM cra_approvals WHERE booking_id=?',[b.id]);
  const rejected=ap.some(x=>x.decision==='Rejected');
  const allApproved=ap.every(x=>x.decision==='Approved');
  if(rejected) await pool.query("UPDATE cra_bookings SET status='Rejected',reviewed_by=?,faculty_note=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",[approver_name.trim(),note||null,b.id]);
  else if(allApproved) await pool.query("UPDATE cra_bookings SET status='Approved',reviewed_by=?,faculty_note=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?",[approver_name.trim(),note||null,b.id]);
  res.json({message:rejected?'Request rejected and saved.':allApproved?'All required approvals complete. Booking approved and saved.':'Approval recorded; another required approval is still pending.'});
}));
app.post('/api/bookings/:id/cancel', asyncRoute(async (req,res)=>{
  const [rows]=await pool.query('SELECT id,status,booking_date,start_time FROM cra_bookings WHERE id=?',[req.params.id]);
  if(!rows.length) return res.status(404).json({error:'Booking not found.'});
  const b=rows[0];
  if(!['Pending','Approved'].includes(b.status)) return res.status(409).json({error:'This booking cannot be cancelled.'});
  const start=new Date(`${b.booking_date.toISOString?b.booking_date.toISOString().slice(0,10):String(b.booking_date).slice(0,10)}T${b.start_time}`);
  if(start.getTime()-Date.now()<24*60*60*1000) return res.status(409).json({error:'Bookings can only be cancelled at least 24 hours before the start time.'});
  await pool.query("UPDATE cra_bookings SET status='Cancelled' WHERE id=?",[b.id]);
  res.json({message:'Booking cancelled.'});
}));
app.post('/api/bookings/:id/edit-request', asyncRoute(async (req,res)=>{
  const {booking_date,start_time,end_time}=req.body;
  if(!booking_date||!start_time||!end_time||start_time>=end_time) return res.status(400).json({error:'Enter a valid date and time range.'});
  const [rows]=await pool.query('SELECT id,status FROM cra_bookings WHERE id=?',[req.params.id]);
  if(!rows.length) return res.status(404).json({error:'Booking not found.'});
  if(!['Pending','Approved'].includes(rows[0].status)) return res.status(409).json({error:'This booking cannot be edited.'});
  await pool.query("UPDATE cra_bookings SET edit_status='Pending',proposed_date=?,proposed_start=?,proposed_end=? WHERE id=?",[booking_date,start_time,end_time,req.params.id]);
  res.json({message:'Edit request sent for faculty approval.'});
}));
app.patch('/api/bookings/:id/edit-review', asyncRoute(async (req,res)=>{
  const {decision,approver_name}=req.body;
  if(!['Approved','Rejected'].includes(decision)||!approver_name) return res.status(400).json({error:'Provide decision and faculty name.'});
  const [rows]=await pool.query("SELECT * FROM cra_bookings WHERE id=? AND edit_status='Pending'",[req.params.id]);
  if(!rows.length) return res.status(404).json({error:'No pending edit request found.'});
  const b=rows[0];
  if(decision==='Approved'){
    const [conf]=await pool.query(`SELECT id FROM cra_bookings WHERE id<>? AND resource_id=? AND booking_date=?
      AND status IN ('Pending','Approved') AND start_time<? AND end_time>? LIMIT 1`,
      [b.id,b.resource_id,b.proposed_date,b.proposed_end,b.proposed_start]);
    if(conf.length) return res.status(409).json({error:'The requested new time conflicts with another booking.'});
    await pool.query("UPDATE cra_bookings SET booking_date=proposed_date,start_time=proposed_start,end_time=proposed_end,edit_status='Approved',proposed_date=NULL,proposed_start=NULL,proposed_end=NULL,reviewed_by=? WHERE id=?",[approver_name,b.id]);
  } else {
    await pool.query("UPDATE cra_bookings SET edit_status='Rejected',proposed_date=NULL,proposed_start=NULL,proposed_end=NULL,reviewed_by=? WHERE id=?",[approver_name,b.id]);
  }
  res.json({message:`Edit request ${decision.toLowerCase()}.`});
}));
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Server/database error. Check the VS Code terminal.'});});
initDb().then(()=>app.listen(PORT,()=>console.log(`Campus Resource Allocator running at http://localhost:${PORT}`)))
.catch(err=>{console.error('Database setup failed:',err.message);process.exit(1);});
