# Campus Resource Allocator — Full Workflow Rewrite

## Included workflows
- Overview dashboard with live request, pending, approved, and resource counts
- Resource directory with search; Admin can add/deactivate resources
- Booking request form and persisted MySQL booking history
- Role switch: Student, Faculty, DSW, Admin (demo switch, not authentication)
- Faculty approvals and DSW co-approval for overnight events
- Booking calendar showing approved bookings
- Cancellation limited to at least 24 hours before the booking starts
- Edit requests routed for faculty approval
- Conflict and capacity checks
- MySQL tables are created automatically without dropping existing tables

## Install
1. Back up your project folder first.
2. Copy `server.js`, `package.json`, and the `public` folder from this project into your existing project folder.
3. Keep your current `.env` in the project root. It should have:
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your actual MySQL password
   DB_NAME=resource
   PORT=3000
4. In VS Code Terminal in the project folder run `npm install`.
5. Stop any old server with Ctrl+C, then run `node server.js`.
6. Open http://localhost:3000 and confirm http://localhost:3000/api/health returns ok:true.

## Data safety
This project creates `cra_resources`, `cra_bookings`, and `cra_approvals` in the existing `resource` database. It does not drop or truncate your existing tables. Seed resources are inserted only if `cra_resources` is empty.

## Verify data in Workbench
SELECT * FROM cra_resources;
SELECT * FROM cra_bookings ORDER BY id DESC;
SELECT * FROM cra_approvals ORDER BY id DESC;

## Important limitations
The role selector is for a classroom demo only. It is not authentication and should not be exposed publicly. For real deployment, add secure login and server-side role checks. Overnight requests need Faculty and DSW approval; edit and cancellation rules are demo-level workflow implementations and should be tested against your institution's exact policies.
